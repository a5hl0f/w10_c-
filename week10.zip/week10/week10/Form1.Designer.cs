﻿
namespace week10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.op2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.op1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.c = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.p = new System.Windows.Forms.Button();
            this.s = new System.Windows.Forms.Button();
            this.m = new System.Windows.Forms.Button();
            this.r = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.d = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // op2
            // 
            this.op2.Location = new System.Drawing.Point(272, 68);
            this.op2.Name = "op2";
            this.op2.Size = new System.Drawing.Size(100, 22);
            this.op2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(214, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "op2";
            // 
            // op1
            // 
            this.op1.Location = new System.Drawing.Point(86, 66);
            this.op1.Name = "op1";
            this.op1.Size = new System.Drawing.Size(100, 22);
            this.op1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "op1";
            // 
            // c
            // 
            this.c.Location = new System.Drawing.Point(86, 352);
            this.c.Name = "c";
            this.c.Size = new System.Drawing.Size(100, 23);
            this.c.TabIndex = 8;
            this.c.Text = "calculate";
            this.c.UseVisualStyleBackColor = true;
            this.c.Click += new System.EventHandler(this.button_click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(272, 352);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(100, 23);
            this.close.TabIndex = 9;
            this.close.Text = "close";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.c_Click);
            // 
            // p
            // 
            this.p.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.p.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p.Location = new System.Drawing.Point(168, 140);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(95, 40);
            this.p.TabIndex = 10;
            this.p.Text = "+";
            this.p.UseVisualStyleBackColor = false;
            this.p.Click += new System.EventHandler(this.operator_click);
            // 
            // s
            // 
            this.s.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s.Location = new System.Drawing.Point(168, 186);
            this.s.Name = "s";
            this.s.Size = new System.Drawing.Size(95, 40);
            this.s.TabIndex = 11;
            this.s.Text = "-";
            this.s.UseVisualStyleBackColor = true;
            this.s.Click += new System.EventHandler(this.operator_click);
            // 
            // m
            // 
            this.m.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.m.Location = new System.Drawing.Point(168, 232);
            this.m.Name = "m";
            this.m.Size = new System.Drawing.Size(95, 40);
            this.m.TabIndex = 12;
            this.m.Text = "*";
            this.m.UseVisualStyleBackColor = true;
            this.m.Click += new System.EventHandler(this.operator_click);
            // 
            // r
            // 
            this.r.Location = new System.Drawing.Point(245, 24);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(127, 22);
            this.r.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(176, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "result";
            // 
            // d
            // 
            this.d.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.d.Location = new System.Drawing.Point(169, 274);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(95, 40);
            this.d.TabIndex = 15;
            this.d.Text = "/";
            this.d.UseVisualStyleBackColor = true;
            this.d.Click += new System.EventHandler(this.operator_click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 376);
            this.Controls.Add(this.d);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.r);
            this.Controls.Add(this.m);
            this.Controls.Add(this.s);
            this.Controls.Add(this.p);
            this.Controls.Add(this.close);
            this.Controls.Add(this.c);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.op1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.op2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(423, 423);
            this.MinimumSize = new System.Drawing.Size(423, 423);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox op2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox op1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button c;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button p;
        private System.Windows.Forms.Button s;
        private System.Windows.Forms.Button m;
        private System.Windows.Forms.TextBox r;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button d;
    }
}

