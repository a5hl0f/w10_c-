﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace week10
{
    public partial class Form1 : Form
    {
        double result;
        string value;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void c_Click(object sender, EventArgs e)
        {
            Close();
         
            
            

            
        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            value = button.Text;
          

        }

        private void button_click(object sender, EventArgs e)
        {
            switch (value)
            {
                case "+":
                    r.Text = (int.Parse(op1.Text) + int.Parse(op2.Text)).ToString();
                    break;
                case "-":
                    r.Text = (int.Parse(op1.Text) - int.Parse(op2.Text)).ToString();
                    break;
                case "*":
                    r.Text = (int.Parse(op1.Text) * int.Parse(op2.Text)).ToString();
                    break;
                case "/":
                    r.Text = (int.Parse(op1.Text) / int.Parse(op2.Text)).ToString();
                    break;
                

                case null:
                    r.Text = null;
                    break;

            }
        }

        private void operator_clic(object sender, EventArgs e)
        {

        } 
    }
}
